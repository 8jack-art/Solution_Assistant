"""ACP server entry point."""

from mini_agent.acp import main

if __name__ == "__main__":
    main()
